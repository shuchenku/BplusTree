package edu.brandeis.cs127.pa3;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({
	Data1Test.class,
	Data2Test.class,
	Data3Test.class,
	Data4Test.class,
	Data5Test.class
})
public class AllProvidedTests {

}
